from flask import current_app, Blueprint, request, jsonify
import json

from models import Url, Shortcode, Redirect, Stat
from exceptions import InvalidRequestPayload, ShortcodeAlreadyInUse, InvalidShortcode, ShortcodeNotFound

import logging

LOGGER = logging.getLogger(__name__)

blueprint_shorten_url = Blueprint('shorten_url', __name__)
blueprint_get_url = Blueprint('get_url', __name__)
blueprint_get_stats = Blueprint('get_stats', __name__)


@blueprint_shorten_url.route('/shorten', methods=['POST'])
def shorten_url():
    if not request.is_json:
        raise InvalidRequestPayload('Unsupported Media Type: Invalid JSON')
    request_data = request.get_json()
    if 'url' not in request_data:
        raise InvalidRequestPayload('Url not present')
    request_url = request_data['url']
    request_shortcode = request_data['shortcode']

    shortcode = Url.insert_url(url=request_url, shortcode=request_shortcode)
    response = jsonify({
        "shortcode": shortcode
    })
    response.status_code = 201
    return response


@blueprint_get_url.route('/<shortcode>', methods=['GET'])
def get_url(shortcode):
    redirect_url = Redirect.redirect(_shortcode=shortcode)
    response = jsonify()
    response.status_code = 302
    response.headers['Location'] = redirect_url
    return response


@blueprint_get_stats.route('/<shortcode>/stats', methods=['GET'])
def get_stats(shortcode):
    stats = Stat.get_stats(shortcode=shortcode)
    print(stats)
    response = jsonify(stats)
    response.status_code = 302
    return response
