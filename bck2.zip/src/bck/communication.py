from enum import Enum


class Response(Enum):
    """
    This object contains the messages that are send
    as callback response by the API endpoint methods.
    """
    DEFAULT_ERROR_HANDLER = "This method is not allowed"
    INVALID_REQUEST_PAYLOAD = "Invalid request payload, the payload is not valid {FORMAT}"
    INVALID_REQUEST_SCHEMA = "Invalid request schema: {REASON}"

    SERVER_UNAVAILABLE = "Service temporarily unavailable, try again in {SECONDS} seconds"
    SERVER_ERROR = "The service was unable to handle the request"

    INVALID_CLIENT_REQUEST = "Invalid client credentials"
    INVALID_GRANT_TYPE = "Invalid grant type, use the grant type bound to your account"

    AUTHORIZATION_SUCCESSFUL = "Authorization successful"

    INVALID_AUTH_TOKEN = "Invalid authorization token"
    EXPIRED_AUTH_TOKEN = "Expired authorization code: {TYPE}"
    AUTH_TOKEN_NOT_FOUND = "No authorization code was found in the request"

    KADASTER_KLIC_CREATE_SUCCESS = "Klic creation request was successful"
    KADASTER_KLIC_RETRIEVE_SUCCESS = "Klic status and result request was successful"
    KADASTER_KLIC_RETRIEVE_UNAUTHORIZED = "No task found for current client with task correlation_id: {CORRELATION_ID}"


class Status:
    """
    This object contains the status strings and corresponding
    status codes that are send alongside the message as callback
    response by the API endpoint methods.
    """
    ERROR = "ERROR", 401
    FORBIDDEN = "FORBIDDEN", 403
    SUCCESS = "SUCCESS", 200
    UNAVAILABLE = "UNAVAILABLE", 503
    SERVER_ERROR = "ERROR", 500
    METHOD_NOT_ALLOWED = "MethodNotAllowed", 405
