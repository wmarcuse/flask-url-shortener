from abc import ABC, abstractmethod
from flask import jsonify


class AbstractHttpException(ABC, Exception):
    def __init__(self, *args, payload=None,):
        if args:
            self._message = args[0]
        else:
            self._message = self.MESSAGE
        self.statement = '{EXCEPTION}: {MESSAGE}'.format(
            EXCEPTION=self.__class__.__name__,
            MESSAGE=self._message
        )
        self.payload = payload

    @classmethod
    def __init_subclass__(cls):
        required_parameters = [
            'STATUS_CODE',
            'MESSAGE'
        ]
        for param in required_parameters:
            if not hasattr(cls, param):
                raise NotImplementedError('{EXCEPTION} cannot be instantiated without: {PARAM}'.format(
                    EXCEPTION=cls.__name__,
                    PARAM=param
                ))

    def http_response(self):
        response = dict(self.payload or ())
        response['message'] = self._message
        http_package = jsonify(response)
        http_package.status_code = self.STATUS_CODE
        return http_package

    def __str__(self):
        return self.statement


class InvalidRequestPayload(AbstractHttpException):
    STATUS_CODE = 400
    MESSAGE = 'The provided request payload is invalid'


class ShortcodeAlreadyInUse(AbstractHttpException):
    STATUS_CODE = 409
    MESSAGE = 'Shortcode already in use'


class ShortcodeNotFound(AbstractHttpException):
    STATUS_CODE = 404
    MESSAGE = 'Shortcode not found'


class InvalidShortcode(AbstractHttpException):
    STATUS_CODE = 412
    MESSAGE = 'The provided shortcode is invalid'
