from sqlalchemy.sql import func, text
from sqlalchemy.orm import backref
import string
import random
import re

from db import db as dbs
from exceptions import ShortcodeAlreadyInUse, InvalidShortcode, ShortcodeNotFound


class Url(dbs.Model):

    __tablename__ = 'url'
    __table_args__ = (
        dbs.UniqueConstraint(
            'url'
        ),
    )

    id = dbs.Column(dbs.Integer, primary_key=True)
    url = dbs.Column(dbs.String)
    # shortcode = dbs.Column(dbs.String, dbs.ForeignKey('shortcode.id'))
    shortcode = dbs.relationship('Shortcode', uselist=False, back_populates='url')

    @classmethod
    def insert_url(cls, url, shortcode=None):
        _url = Url.query.filter_by(url=url).first()
        if _url is None:
            _shortcode = Shortcode.insert(shortcode=shortcode)
            _url = cls(url=url, shortcode=_shortcode)

        dbs.session.add(_url)
        dbs.session.commit()
        return _url.shortcode.shortcode


class Shortcode(dbs.Model):

    __tablename__ = 'shortcode'
    __table_args__ = (
        dbs.UniqueConstraint(
            'shortcode'
        ),
    )

    id = dbs.Column(dbs.Integer, primary_key=True)
    urlId = dbs.Column(dbs.Integer, dbs.ForeignKey('url.id'))
    url = dbs.relationship('Url', back_populates='shortcode')
    shortcode = dbs.Column(dbs.String)
    stats = dbs.relationship('Stat', uselist=False, back_populates='shortcode')
    redirect = dbs.relationship('Redirect', uselist=False, back_populates='shortcode')

    @staticmethod
    def generate_random(length=6, chars=string.ascii_lowercase + string.digits + '_'):
        return ''.join(random.choice(chars) for _ in range(length))

    @staticmethod
    def check_validity(shortcode):
        desired_pattern = re.compile(r'^[a-z0-9_]{6}$')
        match = desired_pattern.match(shortcode)
        if match is not None:
            return True
        else:
            return False

    @classmethod
    def check_in_use(cls, shortcode):
        _shortcode = cls.query.filter_by(shortcode=shortcode).first()
        if _shortcode is None:
            return False
        else:
            return True

    @classmethod
    def generate_new(cls):
        checked_shortcode = None
        while True:
            random_shortcode = cls.generate_random()
            shortcode_in_use = cls.check_in_use(shortcode=random_shortcode)
            if shortcode_in_use is False:
                checked_shortcode = random_shortcode
                break
        return checked_shortcode

    @classmethod
    def insert(cls, shortcode):
        if shortcode is not None:
            shortcode_in_use = cls.check_in_use(shortcode=shortcode)
            if shortcode_in_use is False:
                shortcode_valid = cls.check_validity(shortcode=shortcode)
                if shortcode_valid is True:
                    accepted_shortcode = shortcode
                else:
                    raise InvalidShortcode
            else:
                raise ShortcodeAlreadyInUse
        else:
            accepted_shortcode = cls.generate_new()
        _stat = Stat()
        _shortcode = cls(
            shortcode=accepted_shortcode,
            stats=_stat
        )
        return _shortcode

    # @classmethod
    # def get_redirect(cls, shortcode):
    #     in_use = cls.check_in_use(shortcode=shortcode)
    #     if in_use is True:
    #         _shortcode = cls.query.filter_by(shortcode=shortcode).first()
    #         _shortcode.redirect = Redirect.redirect(_shortcode=shortcode)
    #         return _shortcode.url
    #     else:
    #         raise ShortcodeNotFound


class Stat(dbs.Model):
    __tablename__ = 'stat'

    id = dbs.Column(dbs.Integer, primary_key=True)
    shortcodeId = dbs.Column(dbs.Integer, dbs.ForeignKey('shortcode.id'))
    shortcode = dbs.relationship('Shortcode', back_populates='stats')
    created = dbs.Column(dbs.DateTime(timezone=True), server_default=func.now())
    # redirect_id = dbs.Column(dbs.Integer, dbs.ForeignKey('redirect.id'))
    # idredirect = dbs.relationship('Redirect', uselist=False, post_update=True, foreign_keys=[redirect_id])
    redirectId = dbs.Column(dbs.Integer, dbs.ForeignKey('redirect.id'))
    # ccs = dbs.relationship('Redirect', secondary='Shortcode', primaryjoin='Stat.shortcodeId == Shortcode.id', secondaryjoin='Redirect.shortcodeId == Shortcode.id', viewonly=True)


class Redirect(dbs.Model):
    __tablename__ = 'redirect'

    id = dbs.Column(dbs.Integer, primary_key=True)
    shortcodeId = dbs.Column(dbs.Integer, dbs.ForeignKey('shortcode.id'))
    shortcode = dbs.relationship('Shortcode', back_populates='redirect', foreign_keys=[shortcodeId])
    # statId = dbs.Column(dbs.Integer, dbs.ForeignKey('stat.id'))
    # stat = dbs.relationship('Stat', back_populates='redirect', foreign_keys=[statId])
    # redirectUrl = dbs.Column(dbs.String, dbs.ForeignKey('shortcode.url'))
    # red = dbs.relationship('Shortcode', back_populates='redirect', foreign_keys=[redirectUrl])
    lastRedirect = dbs.Column(dbs.DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    redirectCount = dbs.Column(dbs.Integer)

    @classmethod
    def check_in_use(cls, _shortcode):
        print(Stat)
        _redirect = cls.query.filter(cls.shortcode.has(shortcode=_shortcode)).first()
        if _redirect is None:
            return False
        else:
            return True

    @classmethod
    def redirect(cls, _shortcode):
        in_use = cls.check_in_use(_shortcode=_shortcode)
        if in_use is True:
            _redirect = cls.query.filter(cls.shortcode.has(shortcode=_shortcode)).first()
            _redirect.redirectCount += 1

        else:
            if Shortcode.check_in_use(shortcode=_shortcode) is False:
                raise ShortcodeNotFound
            _redirect = cls(
                shortcode=Shortcode.query.filter_by(shortcode=_shortcode).first(),
                # stat=Stat.query.filter(Stat.shortcode.has(shortcode=_shortcode)).first(),
                redirectCount=1
            )
            dbs.session.add(_redirect)
        dbs.session.commit()
        return _redirect.shortcode.url.url

